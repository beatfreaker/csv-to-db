import React, { Component } from "react";

class FileUploader extends Component {
  state = {};

  onSelectFile = e => {
    const files = e.target.files;
    this.setState({
      fileToUpload: files[0]
    });
  };

  onUploadFile() {
    const { fileToUpload } = this.state;
    if (!fileToUpload) {
      alert("Please select the file first");
    }
    const formData = new FormData();
    formData.append("file", fileToUpload);
    this.setState({ isUploading: true });
    fetch("http://localhost:8080/upload", { method: "POST", body: formData })
      .then(r => {
        this.setState({ isUploading: false });
        fetch("http://localhost:8080/users")
          .then(resp => resp.json())
          .then(users => {
            this.setState({ data: JSON.stringify(users, null, 2) });
          });
      })
      .catch(e => {
        document.querySelector("#process").innerHTML = "Failed uploading file.";
      });
  }

  render() {
    return (
      <div>
        <div className="button">
          <label htmlFor="single">Select File</label>
          <input type="file" id="single" onChange={this.onSelectFile} />
        </div>
        <div>
          <button onClick={this.onUploadFile}>Upload File</button>
        </div>
        <div>
          <label id="process" />
        </div>

        <div>
          <label>Data fetched from database:</label>
          <pre id="user-data">{this.state.data}</pre>
        </div>
      </div>
    );
  }
}

export default FileUploader;
