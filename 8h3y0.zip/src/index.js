import React from "react";
import ReactDOM from "react-dom";
import FileUploader from "./FileUploader";
import "./styles.css";

function App() {
  return (
    <div className="App">
      <FileUploader />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
